from http.server import HTTPServer, BaseHTTPRequestHandler

#isHappyNumber() will determine whether a number is happy or not
def sumOfDigits(num):
    rem = sum = 0

    #Calculates the sum of squares of digits
    while(num > 0):
        rem = num%10
        sum = sum + (rem*rem)
        num = num//10
    return sum

def isHappy(num):
    result = sumOfDigits(num)
    while(result != 1 and result != 4):
        result = sumOfDigits(result)
    if(result == 1):
        return "It is a happy number"
    else:
        return "It is an unhappy number"





#
class MyServerHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        # handle a post request
        content_length = int(self.headers.get('content-length', '0').strip())
        request = self.rfile.read(content_length)

        # decode n
        n = int(request.strip())

        # call the actual code to run it
        answer = isHappy(n)

        # encode the response
        encoded = str(answer)

        # send it back
        self.send_response(200)
        self.end_headers()  # write HTTP headers
        self.wfile.write(bytes(f'{encoded}\r\n', 'utf-8')) # write body


web_server = HTTPServer(('', 8090), MyServerHandler)

try:
    web_server.serve_forever()
except KeyboardInterrupt:
    print("Exiting...")

web_server.server_close()
